package com.ddu.pro.service;

import java.util.ArrayList;

import com.ddu.pro.command.TestVO;

public interface TestService {
	ArrayList<TestVO> getTest();
}
