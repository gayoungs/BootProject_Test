package com.ddu.pro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProApplicationTests {

	@Test
	void contextLoads() {
	}

}
