package com.coding404.bnb.service;

import javax.servlet.http.HttpSession;

import com.coding404.bnb.command.BusinessVO;

public interface BusinessService {
	int loginBusiness(BusinessVO reqBusinessVO, HttpSession session);
	int registerBusiness(BusinessVO business);
	
}