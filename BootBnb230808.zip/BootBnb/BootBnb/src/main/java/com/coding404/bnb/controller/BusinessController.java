package com.coding404.bnb.controller;

import com.coding404.bnb.command.BusinessVO;
import com.coding404.bnb.service.BusinessService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/business")
public class BusinessController {

    @Autowired
    @Qualifier("businessService")
    private BusinessService businessService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("business", new BusinessVO());
        return "business/register";
    }

    @PostMapping("/register")
    public String registerBusiness(@ModelAttribute("business") @Valid BusinessVO business, RedirectAttributes ra, BindingResult bindingResult) {
    	
        if (bindingResult.hasErrors()) {
            return "business/register";
        }
        
        int result = businessService.registerBusiness(business);
        
        if (result == 1) {
        	ra.addFlashAttribute("msg", "중복된 사용자 ID입니다.");
            return "redirect:/business/register";
        }
        
        return "redirect:/business/login";
    }
    
    
//    @PostMapping("/register")
//    public String registerBusiness(@Valid @ModelAttribute("vo") BusinessVO vo, Errors errors, Model model) {
//    	
//	if(errors.hasErrors()) {//에러가 있다면 true, 없다면 false
//			
//			//System.out.println(vo.toString());
//			//System.out.println(errors);
//			
//			//1.유효성 검사에 실패한 에러 확인
//			List<FieldError> list = errors.getFieldErrors();
//			
//			//2. 반복처리
//			for(FieldError err : list ) {
//				//System.out.println(err);
//				//System.out.println(err.getField()); //에러가 난 필드명
//				//System.out.println(err.getDefaultMessage()); //메시지 출력
//			    //System.out.println(err.isBindingFailure()); //유효성검사에 의해서 err라면 false, 아니라면 true반환
//			
//				//model.addAttribute("valid_" + err.getField(), err.getDefaultMessage());
//				
//				if(err.isBindingFailure()) {
//					model.addAttribute("valid_" + err.getField(),"잘못된 값 입력입니다");
//				} else {
//					model.addAttribute("valid_" + err.getField(),err.getDefaultMessage());
//				}
//			
//			}
//			
//			
//			
//		} //err end
//		
//		
//		return "valid/view"; //실패시 원래 화면으로
//		
//		
//	}


    @GetMapping("/login")
    public String showLoginForm() {
        return "business/login";
    }
    
    @PostMapping("/login")
    public String loginUser(BusinessVO reqBusinessVO, RedirectAttributes ra, HttpSession session) {
    	
        int result = businessService.loginBusiness(reqBusinessVO, session);
        
        if(result == 1) {
        	ra.addFlashAttribute("msg", "아이디를 정확히 입력해주세요.");
        	return "redirect:/business/login";
        }
        
        if(result == 2) {
        	ra.addFlashAttribute("msg", "비밀번호를 정확히 입력해주세요.");
        	return "redirect:/business/login";
        }
        
        return "redirect:/main";
    }
}





