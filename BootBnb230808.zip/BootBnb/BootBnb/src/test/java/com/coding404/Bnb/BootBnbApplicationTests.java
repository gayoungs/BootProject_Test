package com.coding404.Bnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootBnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
