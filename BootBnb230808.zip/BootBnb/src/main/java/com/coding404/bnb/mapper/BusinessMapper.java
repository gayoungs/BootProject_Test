package com.coding404.bnb.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.coding404.bnb.command.BusinessVO;

@Mapper
public interface BusinessMapper {
    void insertBusiness(BusinessVO business);
    BusinessVO getBusinessById(String bn_Id);
    int checkDuplicateBusinessId(String string);
    
}


