package com.coding404.bnb.controller;

import com.coding404.bnb.command.BusinessVO;
import com.coding404.bnb.command.ResVO;
import com.coding404.bnb.service.BusinessService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@Controller
@RequestMapping("/business")
public class BusinessController {

    @Autowired
    @Qualifier("businessService")
    private BusinessService businessService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("vo", new BusinessVO());
        return "business/register";
    }

//    @PostMapping("/register")
//    public String registerBusiness(@ModelAttribute("business") @Valid BusinessVO business, RedirectAttributes ra, BindingResult bindingResult) {
//    	
//        if (bindingResult.hasErrors()) {
//            return "business/register";
//        }
//        
//        int result = businessService.registerBusiness(business);
//        
//        if (result == 1) {
//        	ra.addFlashAttribute("msg", "중복된 사용자 ID입니다.");
//            return "redirect:/business/register";
//        }
//        
//        return "redirect:/business/login";
//    }
    
    
    @PostMapping("/register")
	public String actionForm(@ModelAttribute("vo") @Valid BusinessVO vo, Errors error, Model model,BindingResult bindingResult, RedirectAttributes ra) {
		
	
		if(error.hasErrors()) { 
			List<FieldError> list=error.getFieldErrors(); 
			for(FieldError err: list) {
				
				if(err.isBindingFailure()) {
					model.addAttribute("valid_"+err.getField(),"형식이 올바르지 않습니다");
				}else {
					model.addAttribute("valid_"+err.getField(),err.getDefaultMessage());
				}
			}
			
			model.addAttribute("vo", vo);
			return "business/register";//원래 화면으로
		}
		
		 int result = businessService.registerBusiness(vo);
		 	
		 	
		 
		  if (result == 1) {
	
            ra.addFlashAttribute("msg", "중복된 사용자 ID입니다.");
            return "redirect:/business/register";
        }
		 
		  return "redirect:/business/login";
	}


    
	
    
//    @PostMapping("/register")
//    public String registerBusiness(@ModelAttribute("vo") @Valid BusinessVO vo, RedirectAttributes ra, Errors errors, BindingResult bindingResult, Model model) {
//        if (bindingResult.hasErrors()) {
//        	List<FieldError> errors1 = bindingResult.getFieldErrors();
//            for (FieldError err : errors1) {
//                if (err.isBindingFailure()) {
//                    model.addAttribute("valid_" + err.getField(), "잘못된 값 입력입니다");
//               } else {
//                    model.addAttribute("valid_" + err.getField(), err.getDefaultMessage());
//                }
//                return "business/register";
//            }
//            return "business/login";
//        }
//
//        
//        int result = businessService.registerBusiness(vo);
//
//        if (result == 1) {
//            ra.addFlashAttribute("msg", "중복된 사용자 ID입니다.");
//            return "redirect:/business/register";
//        }
//
//        return "redirect:/business/login";
//    }
    


    @GetMapping("/login")
    public String showLoginForm() {
        return "business/login";
    }
    
    @PostMapping("/login")
    public String loginUser(BusinessVO reqBusinessVO, RedirectAttributes ra, HttpSession session) {
    	
        int result = businessService.loginBusiness(reqBusinessVO, session);
        
        if(result == 1) {
        	ra.addFlashAttribute("msg", "아이디를 정확히 입력해주세요.");
        	return "redirect:/business/login";
        }
        
        if(result == 2) {
        	ra.addFlashAttribute("msg", "비밀번호를 정확히 입력해주세요.");
        	return "redirect:/business/login";
        }
        
        return "redirect:/main";
    }


	@PostMapping("/check_duplicate")
	@ResponseBody
	public ResponseEntity<?> checkDuplicate(@RequestParam String bn_Id) {
		
        final Pattern pattern = Pattern.compile("[a-zA-Z0-9]{8,}", Pattern.CASE_INSENSITIVE);
        final Matcher matcher = pattern.matcher(bn_Id);
        if(!matcher.matches()) {
			return new ResponseEntity<>(
					ResVO.builder()
					.code(1)
					.message("아이디는 영문자, 숫자 8자 이상이어야 합니다.")
					.build(),
					HttpStatus.BAD_REQUEST
			);
        }
		
		if(bn_Id == null || bn_Id.equals("")) {
			return new ResponseEntity<>(
					ResVO.builder()
					.code(1)
					.message("아이디를 입력해주세요.")
					.build(),
					HttpStatus.BAD_REQUEST
			);
		}
		
		int result = businessService.checkDuplicate(bn_Id);
		
		if(result == 1) {
			
			return new ResponseEntity<>(
					ResVO.builder()
					.code(1)
					.message("중복된 사용자 ID입니다.")
					.build(),
					HttpStatus.BAD_REQUEST
			);
			
		}
	  
		return new ResponseEntity<>(
				ResVO.builder()
				.code(0)
				.message("사용가능한 ID입니다.")
				.build(),
			HttpStatus.OK
		);

	}
}





